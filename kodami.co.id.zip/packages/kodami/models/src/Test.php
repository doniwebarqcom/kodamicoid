<?php

namespace Kodami\Models;


class Test
{
	function getData()
	{
		return 212;
	}
}
